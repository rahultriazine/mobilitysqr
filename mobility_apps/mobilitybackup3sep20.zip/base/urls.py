# from rest_framework import routers
#
# from mobility_apps.base.views import RegistrationViewset
#
# router = routers.DefaultRouter(trailing_slash=True)
# router.register(r'signup', RegistrationViewset, base_name="signup")
#
# urlpatterns = [
# ]
#
# urlpatterns += router.urls
