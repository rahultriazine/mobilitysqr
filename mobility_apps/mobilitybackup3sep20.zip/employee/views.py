from django.shortcuts import render
#Create your views here.
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import settings
from api.models import User
from mobility_apps.master.models import Project
from mobility_apps.employee.models import Employee, Employee_Passport_Detail, Employee_Visa_Detail,Employee_Address,Employee_Emails,Employee_Phones,Employee_Nationalid,Employee_Emergency_Contact,Userinfo
from mobility_apps.employee.serializer import EmployeeSerializers,Employee_Passport_DetailSerializers, Employee_Visa_DetailSerializers,Employee_AddressSerializers,Employee_EmailsSerializers,Employee_PhonesSerializers,Employee_NationalidSerializers,Employee_Emergency_ContactSerializers,UserinfoSerializers
from mobility_apps.travel.models import Travel_Request ,Travel_Request_Details,Travel_Request_Dependent,Travel_Request_Draft ,Travel_Request_Details_Draft,Travel_Request_Dependent_Draft,Travel_Request_Action_History,Visa_Request_Action_History,Assignment_Travel_Request_Status,Assignment_Travel_Tax_Grid
from mobility_apps.travel.serializers import Travel_RequestSerializers ,Travel_Request_DetailsSerializers,Travel_Request_DependentSerializers,Travel_Request_DraftSerializers ,Travel_Request_Details_DraftSerializers,Travel_Request_Dependent_DraftSerializers,Travel_Request_Action_HistorySerializers,Visa_Request_Action_HistorySerializers,Assignment_Travel_Request_StatusSerializers,Assignment_Travel_Tax_GridSerializers

from mobility_apps.master.models import Assignment_Group
from mobility_apps.master.serializers.assignment_group import Assignment_GroupSerializers
from rest_framework.generics import RetrieveDestroyAPIView, ListCreateAPIView
from rest_framework.permissions import  (AllowAny,IsAuthenticated)
from django.db.models.deletion import ProtectedError
from django.core.mail import send_mail
from django.db import connection
from django.conf import settings
import pandas as pd
import uuid
import json
from mobility_apps.response_message import *
from django.contrib.auth.hashers import make_password ,check_password
import itertools
from django.db.models import Q
from collections import Counter
import pprint
from django.contrib.auth.hashers import make_password
from django.db import connection
from  collections import namedtuple
from rest_framework.parsers import FileUploadParser,MultiPartParser,FormParser
from django.core.files.storage import FileSystemStorage
from datetime import date
class employeeList(APIView):
    def get(self, request):
        # import ipdb;ipdb.set_trace()
        employees1 = Employee.objects.all()
        serializer = EmployeeSerializers(employees1, many=True)
        return Response(serializer.data)

class emoloyeeinfo(APIView):
    serializer_class = UserinfoSerializers
    permission_classes = (IsAuthenticated,)



    # Get all employee
    # import ipdb;ipdb.set_trace()
    def post(self, request):
        t = date.today()

        employees=Employee.objects.filter(Q(email=request.data['email'])|Q(user_name=request.data['email'])).values("active_start_date","active_end_date")
        if employees[0]['active_start_date']:
            if employees[0]['active_start_date'] and employees[0]['active_end_date']=="":
                employee=Employee.objects.filter(Q(email=request.data['email'])|Q(user_name=request.data['email']),active_start_date__lte=t)
            else:
                employee=Employee.objects.filter(Q(email=request.data['email'])|Q(user_name=request.data['email']),active_start_date__lte=t,active_end_date__gte=t)
        else:
            employee=Employee.objects.filter(Q(email=request.data['email'])|Q(user_name=request.data['email']))
        if employee:
            emp_serializer = EmployeeSerializers(employee,many=True)
            infoemail=emp_serializer.data[0]['email']
            emp_code=emp_serializer.data[0]['emp_code']
            emp_serializer.data[0]['org_id']=emp_serializer.data[0]['organization']
            emp_serializerss = Project.objects.filter(Q(business_lead=infoemail)|Q(client_executive_lead=infoemail)|Q(expense_approver=infoemail)|Q(project_manager=infoemail))
            emp_serializersss = Travel_Request.objects.filter(Q(business_lead=infoemail)|Q(client_executive_lead=infoemail)|Q(expense_approver=infoemail)|Q(project_manager=infoemail))
            employeedeatils_serializerss = Employee.objects.filter(emp_code=emp_code).values('nationality')
            print(employeedeatils_serializerss)
            if employeedeatils_serializerss:
                emp_serializer.data[0]['home']=employeedeatils_serializerss[0]['nationality']
            else:
                emp_serializer.data[0]['home']=""
            employeeemp_serializerss = Employee.objects.filter(supervisor=infoemail)
            if emp_serializerss:
                emp_serializer.data[0]['approver']="1"
            elif employeeemp_serializerss:
                emp_serializer.data[0]['approver']="1"
            elif emp_serializersss:
                emp_serializer.data[0]['approver']="1"
            else:
                emp_serializer.data[0]['approver']="0"
            if emp_serializer.data:
                dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data[0]}
                return Response(dict, status=status.HTTP_200_OK)
            else:
                dict = {'massage': 'data not found', 'status': False}
                return Response(dict, status=status.HTTP_200_OK)

        else:
            dict = {'massage': 'No active account found', 'status': False}
            return Response(dict, status=status.HTTP_200_OK)




class emoloyeedetails(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        employee = request.GET['employee']
        #limits= "15"
        #emp = Employee.objects.raw("select * from employee_userinfo where email LIKE '%"+employee+"%' or emp_code LIKE '%"+employee+"%'")
        emp = Employee.objects.filter(Q(email__contains=employee)|Q(emp_code__contains=employee))
        emp_serializer =EmployeeSerializers(emp,many=True)
        if emp_serializer:
            dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)

class transfer_emoloyeedetails(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        
        #limits= "15"
        #emp = Employee.objects.raw("select * from employee_userinfo where email LIKE '%"+employee+"%' or emp_code LIKE '%"+employee+"%'")
        travel=Travel_Request.objects.filter(travel_req_id=request.GET['travel']).values('approval_level')
        print(travel[0]['approval_level'])
        emp=""
        if travel[0]['approval_level']=="1":
           travelemp=Travel_Request.objects.filter(travel_req_id=request.GET['travel']).values('expense_approver','supervisor')
           emp=Employee.objects.filter(
               Q(email__contains=request.GET['employee'])|Q(emp_code__contains=request.GET['employee'])).exclude(
               Q(email=travelemp[0]['expense_approver'])|
               Q(email=travelemp[0]['supervisor']))

        elif travel[0]['approval_level']=="2":
           travelemp=Travel_Request.objects.filter(travel_req_id=request.GET['travel']).values('expense_approver','project_manager','supervisor')
           emp=Employee.objects.filter(
               Q(email__contains=request.GET['employee'])|Q(emp_code__contains=request.GET['employee'])).exclude(
               Q(email=travelemp[0]['expense_approver'])|Q(email=travelemp[0]['project_manager'])|
               Q(email=travelemp[0]['supervisor']))

        elif travel[0]['approval_level']=="3":
           travelemp=Travel_Request.objects.filter(travel_req_id=request.GET['travel']).values('expense_approver','project_manager','business_lead','supervisor')
           emp=Employee.objects.filter(
               Q(email__contains=request.GET['employee'])|Q(emp_code__contains=request.GET['employee'])).exclude(
               Q(email=travelemp[0]['expense_approver'])|Q(email=travelemp[0]['project_manager'])|
               Q(email=travelemp[0]['business_lead'])|Q(email=travelemp[0]['supervisor']))

        elif travel[0]['approval_level']=="4":
           travelemp=Travel_Request.objects.filter(travel_req_id=request.GET['travel']).values('expense_approver','project_manager','business_lead','client_executive_lead','supervisor')
           emp=Employee.objects.filter(
               Q(email__contains=request.GET['employee'])|Q(emp_code__contains=request.GET['employee'])).exclude(
               Q(email=travelemp[0]['expense_approver'])|Q(email=travelemp[0]['project_manager'])|
               Q(email=travelemp[0]['business_lead'])|Q(email=travelemp[0]['client_executive_lead'])|
               Q(email=travelemp[0]['supervisor']))
        emp_serializer =EmployeeSerializers(emp,many=True)
        if emp_serializer:
            dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)


class getemoloyeedata(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        employee = request.GET['employee']
        #emp = Employee.objects.raw("select * from employee_employee where emp_code LIKE '%"+employee+"%'")
        emp = Employee.objects.filter(Q(email__contains=employee)|Q(emp_code__contains=employee))
        emp_serializer = EmployeeSerializers(emp,many=True)
        dicts=[]
        for employees in emp_serializer.data:
            alldata={}
            emp_code=employees['emp_code']
            emp = Employee.objects.filter(emp_code__contains=emp_code)
            emp_serializers = EmployeeSerializers(emp,many=True)
            alldata['emp_info']=emp_serializers.data
            empadd = Employee_Address.objects.filter(emp_code=emp_code)
            empadd_serializer = Employee_AddressSerializers(empadd,many=True)
            alldata['emp_add']=empadd_serializer.data
            empadd = Employee_Emails.objects.filter(emp_code=emp_code)
            empemails_serializer = Employee_EmailsSerializers(empadd,many=True)
            alldata['emp_emails']=empemails_serializer.data
            empadd = Employee_Emergency_Contact.objects.filter(emp_code=emp_code)
            empemergency_serializer = Employee_Emergency_ContactSerializers(empadd,many=True)
            alldata['emp_emergency']=empemergency_serializer.data
            empadd = Employee_Phones.objects.filter(emp_code=emp_code)
            empphones_serializer = Employee_PhonesSerializers(empadd,many=True)
            alldata['emp_phones']=empphones_serializer.data
            empadd = Employee_Nationalid.objects.filter(emp_code=emp_code)
            empnational_serializer = Employee_NationalidSerializers(empadd,many=True)
            alldata['emp_national']=empnational_serializer.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            alldata['emp_passport']=emppassport_serializer.data
            empadd = Employee_Visa_Detail.objects.filter(emp_code=emp_code)
            empvisa_serializer = Employee_Visa_DetailSerializers(empadd,many=True)
            alldata['emp_visa']=empvisa_serializer.data
            dicts.append(alldata)
        if dicts:
            dict = {'massage': 'data found', 'status': True, 'data':dicts}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': False}
            return Response(dict, status=status.HTTP_200_OK)



class get_delete_update_employee(RetrieveDestroyAPIView):
    http_method_names = ['get', 'put', 'delete', 'head', 'options', 'trace']
    permission_classes = (IsAuthenticated,)
    serializer_class = EmployeeSerializers

    def get_queryset(self,id):
        try:
            employee = Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            return []
        return employee
    def employee_detail_queryset(self,id):
        try:
            employee_details = Employee_Passport_Detail.objects.get(emp_code=id)
        except Employee_Passport_Detail.DoesNotExist:
            return []
        return employee_details

    def employee_visa_queryset(self,id):
        try:
            employee_details = Employee_Visa_Detail.objects.get(emp_code=id)
        except Employee_Visa_Detail.DoesNotExist:
            return []
        return employee_details

    # Get a employee
    def get(self, request):
        # import ipdb;ipdb.set_trace()
        employee = self.get_queryset(request.GET["id"])
        employee_details=self.employee_detail_queryset(request.GET["id"])
        employee_visa_queryset=self.employee_visa_queryset(request.GET["id"])
        dict={"status":True,"msg":"data found","employee_detail":"details not found","employee_visa":"visa details not found"}
        if employee:
            serializer = EmployeeSerializers(employee)
            dict["employee"]=serializer.data
            if employee_details:
                serializer2 = Employee_Passport_DetailSerializers(employee_details)
                dict["employee_detail"] = serializer2.data
            if employee_visa_queryset:
                serializer3 = Employee_Visa_DetailSerializers(employee_visa_queryset)
                dict["employee_visa"]=serializer3.data
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'status':False ,'msg': 'data Not Found'}
            return Response(dict, status=status.HTTP_404_NOT_FOUND)

    # Delete a employee
    def delete(self, request):
        employee = self.get_queryset(request.data["id"])
        if (True):  # If creator is who makes request
            try:
                employee.delete()
            except ProtectedError:
                content = {
                    'status': 'This resource is related to other active record.'
                }
                return Response(content, status=status.HTTP_423_LOCKED)
            content = {
                'status': True,
                "msg":"data deleted successfully"
            }
            return Response(content, status=status.HTTP_204_NO_CONTENT)
        else:
            content = {
                'status': 'user not found'
            }
            return Response(content, status=status.usernotfound)





class get_post_employee_info(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = UserinfoSerializers

    def get_queryset(self):
        employee = Userinfo.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = UserinfoSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()
        employe = Userinfo.objects.filter(
            emp_code=request.data.get('emp_code'))
        try:
            if (employe):
                serializer = UserinfoSerializers(employe, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                dict = {'massage code': '201', 'massage': 'updated successfully', 'status': True, 'data': serializer.data}
                return Response(dict, status=status.HTTP_201_CREATED)
            else:
                request.data['person_id'] = "PER" + str(uuid.uuid4().int)[:6]
                request.data['password'] = str(uuid.uuid4().int)[:6]
                serializer = UserinfoSerializers(data=request.data)
                subject = 'New Password'
                message = ''
                newpassword = '123456'
                html_message = '<h3>Your Username:</h3>'
                html_message += '<p>Username : <b>' +request.data['email']+ '</b> </p>'
                html_message = '<h3>Your Password:</h3>'
                html_message += '<p>Password : <b>' +request.data['password']+ '</b> </p>'
                email_from = settings.EMAIL_HOST_USER
                recipient_list = [request.data['email'],]
                sentemail=send_mail(subject, message, email_from, recipient_list, fail_silently=False, html_message=html_message)
                if serializer.is_valid():
                    serializer.save()
                    dict = {'status_code': '201', 'massage': 'successful', 'status': True, 'data': serializer.data}
                    return Response(dict, status=status.HTTP_201_CREATED)
                else:
                    dict = {'status_code': '201', 'massage': 'unsuccessful', 'status': False, 'data': serializer.errors}
                    return Response(dict, status=status.HTTP_201_CREATED)
        except Exception as e:
            dict = {'status_code': '200', 'massage': 'unsuccessful', 'status': False,'data':[]}
            return Response(dict, status=status.HTTP_200_OK)
        # return  Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class get_post_employee(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = EmployeeSerializers

    def get_queryset(self):
        employee = Employee.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = EmployeeSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()
        employe = Employee.objects.filter(
            emp_code=request.data.get('emp_code')).first()
        print(employe)
        try:
            if (employe):
                serializer = EmployeeSerializers(employe, data=request.data)
                if serializer.is_valid():
                    serializer.save()
                    dict = {'massage code': '201', 'massage': 'successfully', 'status': True, 'data': serializer.data}
                else:
                    print(serializer.errors)
                    dict = {'massage code': '201', 'massage': 'updated successfully', 'status': True, 'data': serializer.errors}
                return Response(dict, status=status.HTTP_201_CREATED)
            else:
                request.data['person_id'] = "PER" + str(uuid.uuid4().int)[:6]
                request.data['password'] = str(uuid.uuid4().int)[:6]
                serializer = EmployeeSerializers(data=request.data)
                subject = 'New Password'
                message = ''
                newpassword = '123456'
                html_message = '<h3>Your Username:</h3>'
                html_message += '<p>Username : <b>' +request.data['email']+ '</b> </p>'
                html_message = '<h3>Your Password:</h3>'
                html_message += '<p>Password : <b>' +request.data['password']+ '</b> </p>'
                email_from = settings.EMAIL_HOST_USER
                recipient_list = [request.data['email'],]
                sentemail=send_mail(subject, message, email_from, recipient_list, fail_silently=False, html_message=html_message)
                if serializer.is_valid():
                    serializer.save()
                    dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': serializer.data}
                    return Response(dict, status=status.HTTP_201_CREATED)
                else:
                    dict = {'massage code': '201', 'massage': 'unsuccessful', 'status': True, 'data': serializer.errors}
                    return Response(dict, status=status.HTTP_201_CREATED)
        except Exception as e:
            dict = {'massage code': 'already exists', 'massage': 'unsuccessful', 'status': False}
            return Response(dict, status=status.HTTP_200_OK)
        # return  Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class get_post_employee_address(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_AddressSerializers

    def get_queryset(self):
        employee = Employee_Address.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_AddressSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Address.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_AddressSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                if empdata['is_primary']==True:
                    employeess=Employee_Emergency_Contact.objects.filter(emp_code=empdata['emp_code'],isAddSameAsEmployee=True)
                    empdatas={}
                    if employeess:
                        for employees in employeess:
                            empdatas.update({"address1":empdata['address1']})
                            empdatas.update({"address2":empdata['address2']})
                            empdatas.update({"address3":empdata['address3']})
                            empdatas.update({"city":empdata['city']})
                            empdatas.update({"state":empdata['state']})
                            empdatas.update({"zip":empdata['zip']})
                            empdatas.update({"country":empdata['country']})
                            serializers = Employee_Emergency_ContactSerializers(employees,data=empdatas)
                            if serializers.is_valid():
                               serializers.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_AddressSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)


class get_post_employee_nationalid(ListCreateAPIView):
    # permission_classes = (IsAuthenticated,)
    serializer_class = Employee_NationalidSerializers

    def get_queryset(self):
        employee = Employee_Nationalid.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_NationalidSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Nationalid.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_NationalidSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_NationalidSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)



class get_post_employee_emails(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_EmailsSerializers

    def get_queryset(self):
        employee = Employee_Emails.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_EmailsSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Emails.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_EmailsSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_EmailsSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)

class get_post_employee_phoneinfo(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_PhonesSerializers

    def get_queryset(self):
        employee = Employee_Phones.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_PhonesSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Phones.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_PhonesSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_PhonesSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)



class get_post_employee_emergencycontact(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Emergency_ContactSerializers

    def get_queryset(self):
        employee = Employee_Emergency_Contact.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_Emergency_ContactSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:

            if empdata['update_id']:
                if empdata['isAddSameAsEmployee']==True:
                    emp=empdata['emp_code']
                    emp_add=Employee_Address.objects.filter(emp_code_id=emp,is_primary=True)
                    if emp_add:
                        emp_add=Employee_AddressSerializers(emp_add,many=True)
                        empdata.update({"address1":emp_add.data[0]['address1']})
                        empdata.update({"address2":emp_add.data[0]['address2']})
                        empdata.update({"address3":emp_add.data[0]['address3']})
                        empdata.update({"city":emp_add.data[0]['city']})
                        empdata.update({"state":emp_add.data[0]['state']})
                        empdata.update({"zip":emp_add.data[0]['zip']})
                        empdata.update({"country":emp_add.data[0]['country']})
                        employee=Employee_Emergency_Contact.objects.filter(id=empdata['update_id']).first()
                        serializer = Employee_Emergency_ContactSerializers(employee,data=empdata)
                        if serializer.is_valid():
                            serializer.save()
                else:
                    employee=Employee_Emergency_Contact.objects.filter(id=empdata['update_id']).first()
                    serializer = Employee_Emergency_ContactSerializers(employee,data=empdata)
                    if serializer.is_valid():
                        serializer.save()
                    dicts.append(serializer.data)

            else:
                if empdata['isAddSameAsEmployee']==True:
                    emp=empdata['emp_code']
                    emp_add=Employee_Address.objects.filter(emp_code_id=emp,is_primary=True)
                    if emp_add:
                        emp_add=Employee_AddressSerializers(emp_add,many=True)
                        empdata.update({"address1":emp_add.data[0]['address1']})
                        empdata.update({"address2":emp_add.data[0]['address2']})
                        empdata.update({"address3":emp_add.data[0]['address3']})
                        empdata.update({"city":emp_add.data[0]['city']})
                        empdata.update({"state":emp_add.data[0]['state']})
                        empdata.update({"zip":emp_add.data[0]['zip']})
                        empdata.update({"country":emp_add.data[0]['country']})
                serializer = Employee_Emergency_ContactSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)


class get_post_employee_passport(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Passport_DetailSerializers

    def get_queryset(self):
        employee = Employee_Passport_Detail.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_Passport_DetailSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Passport_Detail.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_Passport_DetailSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_Passport_DetailSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)

class get_employee_passport(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Passport_DetailSerializers

    def get_queryset(self,emp_id):
        employee = Employee_Passport_Detail.objects.filter(emp_code_id=emp_id)
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset(request.GET['emp_id'])
        emp_serializer = Employee_Passport_DetailSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

class get_post_employee_visa(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Visa_DetailSerializers

    def get_queryset(self):
        employee = Employee_Visa_Detail.objects.all()
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset()
        emp_serializer = Employee_Visa_DetailSerializers(employee,many=True)
        dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

    # Create a new employee
    def post(self, request):
        # import ipdb;ipdb.set_trace()

        # employe = Employee_Address.objects.filter(
        #    emp_code=request.data[0]['emp_code'])
        dicts=[]
        for empdata in request.data:
            if empdata['update_id']:
                employee=Employee_Visa_Detail.objects.filter(id=empdata['update_id']).first()
                serializer = Employee_Visa_DetailSerializers(employee,data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)

            else:
                serializer = Employee_Visa_DetailSerializers(data=empdata)
                if serializer.is_valid():
                    serializer.save()
                dicts.append(serializer.data)
        dict = {'massage code': '201', 'massage': 'successful', 'status': True, 'data': dicts}
        return Response(dict, status=status.HTTP_201_CREATED)#
# bulk upload api(import employee)
class bulk_upload_employee(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = EmployeeSerializers

    # bulk upload api(import employee)
    def post(self, request):
        try:

            data=pd.read_excel(request.data.get("file"),sheet_name=['Sheet1'])
            data1=pd.read_excel(request.data.get("file"),sheet_name=['Sheet2'])

            df2 = pd.concat(data[frame] for frame in data.keys())
            #print(df2)
            #print(data1)
            sucessCount = 0
            failureCount = 0
            alldata=[]
            for i, value in df2.iterrows():

                employe = Employee.objects.filter(
                    emp_code=value['emp_code']).first()
                value=value.to_dict()
                print(employe)


                if (employe):
                    test={}
                    test['empcode']=employe.emp_code
                    test['empemail']=employe.email
                    test['fcount']=failureCount
                    alldata.append(test)
                    failureCount += 1
                    continue



                else:
                    sucessCount += 1
                    serializer = EmployeeSerializers(data=value)
                    data = value
                    if serializer.is_valid():
                        id = serializer.save().id
                    data["emp_code"] = id
                    emp_detail = Employee_Passport_DetailSerializers(data=data)
                    if emp_detail.is_valid():
                        emp_detail.save()
                    emp_visa_detail = Employee_Visa_DetailSerializers(data=data)
                    if emp_visa_detail.is_valid():
                        emp_visa_detail.save()
                    tests=''
                    alldata.append(tests)
            data1=pd.read_excel(request.data.get("file"),sheet_name=['Sheet2'])
            df3 = pd.concat(data1[frame] for frame in data1.keys())
            print(df3)
            alldata1=[]
            infosucessCount = 0
            infofailureCount = 0
            for i, values in df3.iterrows():
                employess = Employee_Address.objects.filter(
                    emp_code=values['emp_code']).first()
                values=values.to_dict()
                print(employess[0])
                if (employess):
                    tests={}
                    tests['emp_code']=employess.emp_code
                    #print(employess.emp_code)
                    alldata1.append(tests)
                    infofailureCount += 1
                    continue



                else:
                    infosucessCount += 1
                    serializer = Employee_AddressSerializers(data=values)
                    if serializer.is_valid():
                        serializer.save()
                    tests=''
                    alldata1.append(tests)
            dict = {'msg': 'Excel upload sucessfully', 'status': True, 'record pass personalinfo':sucessCount,'record fail':infofailureCount, 'record fail personal info':alldata , 'record fail address':alldata1}
            responseList = [dict]
            return Response(responseList, status=status.HTTP_200_OK)
        except Exception as e:
            dict = {'msg': 'Excel format not be corrected', 'status': False}
            return Response(dict, status=status.HTTP_406_NOT_ACCEPTABLE)


#Employee deatils views
class get_post_employee_details(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Passport_DetailSerializers

    def get_queryset(self):
        employee = Employee_Passport_Detail.objects.all()
        return employee

    # Get all employee_detail
    def get(self, request):
        employee = self.get_queryset()
        # paginate_queryset = self.paginate_queryset(employee)
        # serializer = self.serializer_class(paginate_queryset, many=True)
        serializer = Employee_Passport_DetailSerializers(employee,many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        #return self.get_paginated_response(serializer.data)

    # Create a new employee_detail
    def post(self, request):
        employedetail = Employee_Passport_Detail.objects.filter(emp_code__id=request.data.get('id'), department__department_id=request.data.get("department_id")).first()
        if (employedetail):
            serializer = Employee_Passport_DetailSerializers(
                employedetail, data=request.data)
        else:
            serializer = Employee_Passport_DetailSerializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class get_post_employee_visa_details(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Visa_DetailSerializers

    def get_queryset(self):
        employee = Employee_Visa_Detail.objects.all()
        return employee

    # Get all employee
    def get(self, request):
        #import ipdb;ipdb.set_trace()
        employee = self.get_queryset()
        # paginate_queryset = self.paginate_queryset(employee)
        # serializer = self.serializer_class(paginate_queryset, many=True)
        serializer = Employee_Visa_DetailSerializers(employee,many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        #return self.get_paginated_response(serializer.data)

    # Create a new employee
    def post(self, request):
        employevisadetail = Employee_Visa_Detail.objects.filter(emp_code__id=request.data.get('id'), visa_country__country_code=request.data.get('country_code')).first()
        if (employevisadetail):
            serializer = Employee_Visa_DetailSerializers(
                employevisadetail, data=request.data)
        else:
            serializer = Employee_Visa_DetailSerializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class Employee_DetailListCreateAPIView(APIView):

    def get_queryset(self):
        employee_detail = Employee_Passport_Detail.objects.all()
        return employee_detail

    def get(self, request):

        # import ipdb;ipdb.set_trace()
        employee_detail = self.get_queryset()
        serializer = Employee_Passport_DetailSerializers(employee_detail,many=True)
        dict = {'massage': 'data found', 'status': True, 'data': serializer.data}
        #responseList = [dict]
        return Response(dict, status=status.HTTP_200_OK)



class get_post_visa_country(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Employee_Visa_DetailSerializers

    def get_queryset(self,emp_code_id,visa_country_id,visa_type):
        try:
            criterion1 = Q(emp_code=emp_code_id)
            criterion2 = Q(country_code=visa_country_id)
            criterion3 = Q(document_type=visa_type)
            employee= Employee_Visa_Detail.objects.filter(criterion1&criterion2&criterion3)
        # print(visa)
        except Employee.DoesNotExist:

            return []
        return employee

    # Get all visa_purpose
    def get(self, request):
        employee = self.get_queryset(request.GET['emp_code_id'],request.GET['visa_country_id'],request.GET['visa_type'])
        #print(employee)
        # paginate_queryset = self.paginate_queryset(employee)
        # serializer = self.serializer_class(paginate_queryset, many=True)
        if employee:
            serializer =Employee_Visa_DetailSerializers(employee,many=True)
            dict = {"status": True, "message":MSG_SUCESS, "data": serializer.data}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {"status": False,"status_code":200, "message":MSG_FAILED}
            return Response(dict, status=status.HTTP_200_OK)




class get_post_employee_group(ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = Assignment_GroupSerializers
    # Get all visa_purpose
    def list(self, request):
        #queryset = list(itertools.chain(Assignment_Group.objects.all(), Employee.objects.all()))
        #data=cursor.execute('''SELECT * FROM employee_employee where email not in(select emp_email_id from master_assignment_group)''')
        queryset=Employee.objects.raw('SELECT * FROM employee_employee where email not in(select emp_email_id from master_assignment_group)')
        serializer = EmployeeSerializers(queryset, many=True)
        dict = {"status": True, "message":MSG_SUCESS, "data": serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

class get_post_employee_officeaddress(ListCreateAPIView):
    # permission_classes = (IsAuthenticated,)
    serializer_class = Employee_AddressSerializers

    def get_queryset(self,emp_code):
        employee = Employee_Address.objects.filter(emp_code_id=emp_code,address_type='office')
        return employee

    # Get all employee
    # import ipdb;ipdb.set_trace()
    def get(self, request):
        employee = self.get_queryset(request.GET['emp_code'])
        emp_serializer = Employee_AddressSerializers(employee,many=True)
        if emp_serializer.data:
            dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
        else:
            dict = {'massage': 'data not found', 'status': False, 'data':emp_serializer.data}
        return Response(dict, status=status.HTTP_200_OK)

class emoloyeedependent(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        employee = request.GET['employee']
        emp = Employee.objects.filter(emp_code=employee)

        if emp:
            emp_serializer = EmployeeSerializers(emp,many=True)
            for employees in emp_serializer.data:
                emp_code=employees['emp_code']
                empadd = Employee_Emergency_Contact.objects.filter(emp_code=emp_code)
                if empadd:
                    empemergency_serializer = Employee_Emergency_ContactSerializers(empadd,many=True)
                    alldata=[]
                    for data in empemergency_serializer.data:
                        empadd = Employee_Passport_Detail.objects.filter(emp_code=data['emp_code'],relation=data['id']).exclude(passport_status=False)
                        if empadd:
                            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
                            data['emp_passport']=emppassport_serializer.data[0]
                        else:
                            data['emp_passport']=""
                        empadds = Employee_Visa_Detail.objects.filter(emp_code=data['emp_code'],relation=data['id'],country_code=request.GET['country']).exclude(is_validated=False).first()
                        if empadds:
                            empvisa_serializer = Employee_Visa_DetailSerializers(empadds)
                            data['emp_visa']=empvisa_serializer.data
                        else:
                            data['emp_visa']=""
                        alldata.append(data)
                    if alldata:
                        dict = {'massage': 'data found', 'status': True, 'data':alldata}
                    else:
                        dict = {'massage': 'data not found', 'status': False}
                else:
                    dict = {'massage': 'data not found', 'status': False}
        else:
            dict = {'massage': 'data not found', 'status': False}
        return Response(dict, status=status.HTTP_200_OK)

class emoloyee_search_info(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        employee = request.GET['employee']
        limits= "15"
        #emp = Employee.objects.raw("select * from employee_employee where email LIKE '%"+employee+"%' or emp_code LIKE '%"+employee+"%'  limit '"+limits+"'")
        emp = Employee.objects.filter(Q(email__contains=employee)|Q(emp_code__contains=employee))
        emp_serializer =EmployeeSerializers(emp,many=True)
        if emp_serializer:
            dict = {'massage': 'data found', 'status': True, 'data':emp_serializer.data}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)


class forget_password(APIView):
    serializer_class = EmployeeSerializers
    #permission_classes = (IsAuthenticated,)
    def post(self, request):
        #username=request.data['username']
        request.data['email']=request.data['email']
        #request.data['person_id']=request.data['person_id']
        #empcode=request.data['empcode']
        password = str(uuid.uuid4().int)[:6]
        request.data['password'] = make_password(password)
        request.data['istemporary'] = "1"
        userinfo=Employee.objects.filter(email=request.data['email']).first()
        if userinfo:
            cursor = connection.cursor()
            sql="UPDATE api_user SET password='"+request.data['password']+"' WHERE email='"+request.data['email']+"'"
            cursor=cursor.execute(sql)
            cursorss=sql="UPDATE employee_employee SET istemporary='"+request.data['istemporary']+"' WHERE email='"+request.data['email']+"'"
            cursor=cursor.execute(cursorss)
            user_serializer = EmployeeSerializers(userinfo,data=request.data)
            print(user_serializer)
            if user_serializer.is_valid():
                user_serializer.save()
            subject = 'New Password'
            message = ''
            newpassword = '123456'
            html_message = '<h3>Your New Password:</h3>'
            html_message += '<p> User Name <b>: '+request.data['email']+'</b> </p>'
            html_message += '<p>Temporary Password : <b>' +password+ '</b> </p>'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [request.data['email'],]
            sentemail=send_mail(subject, message, email_from, recipient_list, fail_silently=False, html_message=html_message)
            if sentemail:
                dict = {'massage': 'An email has been sent to reset your password', 'status': True}
                return Response(dict, status=status.HTTP_200_OK)
            else:
                dict = {'massage': 'data not found', 'status': True}
                return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'Sorry, we dont recognize this user name', 'status': True,'code':'400'}
            return Response(dict, status=status.HTTP_200_OK)


class is_termandcondtion(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        #username=request.data['username']
        request.data['email']=request.data['email']
        termandcondtion = request.data['termandcondtion']
        #userinfo=Employee.objects.filter(email=request.data['email']).first()
        cursor = connection.cursor()
        sql="UPDATE employee_employee SET termandcondtion='"+str(request.data['termandcondtion'])+"' WHERE user_name='"+request.data['email']+"'"
        cursor=cursor.execute(sql)
        if cursor:
            dict = {'massage': 'success', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)

class reset_password(APIView):
    serializer_class = EmployeeSerializers
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        #username=request.data['username']
        request.data['email']=request.data['email']
        #request.data['person_id']=request.data['person_id']
        #empcode=request.data['empcode']
        passwords = make_password(request.data['password'])
        request.data['istemporary'] = "0"
        userinfo=Userinfo.objects.filter(email=request.data['email']).first()
        print(userinfo)
        cursor = connection.cursor()
        sql="UPDATE api_user SET password='"+passwords+"' WHERE email='"+request.data['email']+"'"
        cursor=cursor.execute(sql)
        cursorss=sql="UPDATE employee_employee SET istemporary='"+request.data['istemporary']+"' WHERE email='"+request.data['email']+"'"
        cursor=cursor.execute(cursorss)
        user_serializer = EmployeeSerializers(userinfo,data=request.data)
        if cursor:
            dict = {'massage': 'success', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)
        else:
            dict = {'massage': 'data not found', 'status': True}
            return Response(dict, status=status.HTTP_200_OK)

class uploadDoc(APIView):
    def post(self, request, format=None):
        file = request.FILES['file']
        fs = FileSystemStorage()
        filename = fs.save(file.name, file)
        uploaded_file_url = fs.url(filename)
        dict = {'massage': 'File uploaded', 'status': True, 'data': uploaded_file_url}
        return Response(dict, status=status.HTTP_200_OK)



class checkemployeeuser(APIView):
    def get(self, request):
        # import ipdb;ipdb.set_trace()
        employees1 = Employee.objects.filter(user_name=request.GET['user_name'])
        if employees1:
            dict = {'massage': 'User Name Already Exist', 'status': True}
        else:
            dict = {'massage': 'User Name Available', 'status': True}
        return Response(dict, status=status.HTTP_200_OK)

class checkemployeeemail(APIView):
    def get(self, request):
        # import ipdb;ipdb.set_trace()
        employees1 = Employee.objects.filter(email=request.GET['email'])
        if employees1:
            dict = {'massage': 'Email Already Exist', 'status': True}
        else:
            dict = {'massage': 'Email Available', 'status': True}
        return Response(dict, status=status.HTTP_200_OK)

class checkemployeeempcode(APIView):
    def get(self, request):
        # import ipdb;ipdb.set_trace()
        employees1 = Employee.objects.filter(emp_code=request.GET['emp_code'])
        if employees1:
            dict = {'massage': 'Employee Code Already Exist', 'status': True}
        else:
            dict = {'massage': 'Employee Code Available', 'status': True}
        return Response(dict, status=status.HTTP_200_OK)



