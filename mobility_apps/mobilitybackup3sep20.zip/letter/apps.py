from django.apps import AppConfig


class VisaRequestConfig(AppConfig):
    name = 'visa_request'
