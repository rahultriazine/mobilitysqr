from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from mobility_apps.employee.models import Employee, Employee_Passport_Detail, Employee_Visa_Detail,Employee_Address,Employee_Emails,Employee_Phones,Employee_Nationalid,Employee_Emergency_Contact,Userinfo
from mobility_apps.employee.serializer import EmployeeSerializers,Employee_Passport_DetailSerializers, Employee_Visa_DetailSerializers,Employee_AddressSerializers,Employee_EmailsSerializers,Employee_PhonesSerializers,Employee_NationalidSerializers,Employee_Emergency_ContactSerializers,UserinfoSerializers
from mobility_apps.travel.models import Travel_Request ,Travel_Request_Details,Travel_Request_Dependent,Travel_Request_Draft ,Travel_Request_Details_Draft,Travel_Request_Dependent_Draft
from mobility_apps.travel.serializers import Travel_RequestSerializers ,Travel_Request_DetailsSerializers,Travel_Request_DependentSerializers,Travel_Request_DraftSerializers ,Travel_Request_Details_DraftSerializers,Travel_Request_Dependent_DraftSerializers
from mobility_apps.employee.models import Employee, Employee_Passport_Detail, Employee_Visa_Detail,Employee_Address,Employee_Emails,Employee_Phones,Employee_Nationalid,Employee_Emergency_Contact,Userinfo
from mobility_apps.letter.models import Letters
from mobility_apps.letter.serializer import LettersSerializers
from mobility_apps.visa.models import Visa_Request , Visa_Request_Document,Visa_Request_Draft
from mobility_apps.visa.serializers import Visa_RequestSerializers,Visa_Request_DocumentSerializers,Visa_Request_DraftSerializers
from mobility_apps.master.models import Country,City,Per_Diem,Dial_Code,Country_Master,State_Master,Location_Master,Taxgrid_Master,Taxgrid_Country,Taxgrid,National_Id
from mobility_apps.master.models import Assignment_Type,Create_Assignment,Secondory_Assignment,Assignment_Extension
from mobility_apps.master.serializers.assinment_type import Assignment_TypeSerializers,Create_AssignmentSerializers,Secondory_AssignmentSerializers,Assignment_ExtensionSerializers

from rest_framework.generics import RetrieveDestroyAPIView, ListCreateAPIView
from rest_framework.permissions import  (AllowAny,IsAuthenticated)
from django.db.models.deletion import ProtectedError
from io import BytesIO
from django.template.loader import get_template
from xhtml2pdf import pisa
from django.core.mail.message import EmailMessage
from django.conf import settings
#import pandas as pd
import uuid
import datetime
from datetime import datetime,date
from mobility_apps.response_message import *
from collections import Counter
from django.db.models import Q

class getassignmentletter(APIView):
    def get(self,request, *args, **kwargs):
        id=request.GET['travel_req_id']
        travel_request= Create_Assignment.objects.filter(Ticket_ID =request.GET['travel_req_id'])
        print(travel_request)
        if travel_request.exists():
            travel_request_serializer = Create_AssignmentSerializers(travel_request,many=True)
            emp_code=travel_request_serializer.data[0]['Employee_ID']
            emp = Employee.objects.filter(email=emp_code)
            emp_serializer = EmployeeSerializers(emp,many=True)
            travel_request_serializer.data[0]['emp_info']=emp_serializer.data
            empcode=emp_serializer.data[0]['emp_code']
            empadd = Employee_Address.objects.filter(emp_code=empcode,address_type="host")
            empadd_serializer = Employee_AddressSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_add']=empadd_serializer.data
            print(empadd_serializer.data)
            #travel_request_serializer.data[0]['date']=datetime.now().date().strftime("%d-%b-%Y")
            travel_requests=Travel_Request.objects.filter(travel_req_id =id)
            travel_request_serializers= Travel_RequestSerializers(travel_requests,many=True)
            travel_request_serializer.data[0]['travel']=travel_request_serializers.data
            travel_requestss=Travel_Request_Details.objects.filter(travel_req_id =id)
            travel_request_serializerss = Travel_Request_DetailsSerializers(travel_requestss,many=True)
            travel_request_serializer.data[0]['details']=travel_request_serializerss.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_passport']=emppassport_serializer.data
            '''empadd = Employee_Emails.objects.filter(emp_code=emp_code)
            empemails_serializer = Employee_EmailsSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emails']=empemails_serializer.data
            empadd = Employee_Emergency_Contact.objects.filter(emp_code=emp_code)
            empemergency_serializer = Employee_Emergency_ContactSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emergency']=empemergency_serializer.data
            empadd = Employee_Phones.objects.filter(emp_code=emp_code)
            empphones_serializer = Employee_PhonesSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_phones']=empphones_serializer.data
            empadd = Employee_Nationalid.objects.filter(emp_code=emp_code)
            empnational_serializer = Employee_NationalidSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_national']=empnational_serializer.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_passport']=emppassport_serializer.data
            empadd = Employee_Visa_Detail.objects.filter(emp_code=emp_code)
            empvisa_serializer = Employee_Visa_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_visa']=empvisa_serializer.data'''

            #data= travel_request_serializer.data
            #print(data)

            datas={}
            for data in travel_request_serializer.data:
               if data['emp_info']:
                  if data['emp_info'][0]['first_name']:
                     first_name=data['emp_info'][0]['first_name']
                  else:
                     first_name=""
                  if data['emp_info'][0]['last_name']:
                     last_name=data['emp_info'][0]['last_name']
                  else:
                     last_name=""
                  if data['emp_info'][0]['nationality']:
                     datas['Citizenship']=data['emp_info'][0]['nationality']
                  else:
                     datas['Citizenship']=""
                  
               datas['AssigneeName']=first_name+' '+last_name
               print(datas['AssigneeName'])
               datas['JobTitle']=""
               datas['TodayDate']=date.today()
               datas['AssignmentStartDate']=data['Actual_Start_Date']
               datas['AssignmentEndDate']=data['Actual_End_Date']
               datas['AssignmentType']=data['Assignment_Type']
               datas['TravelID']=data['Ticket_ID']
               datas['EmployeeID']=data['Employee_ID']
               print(data['details'])
               if data['details']:
                  if data['details'][0]['client_name']:
                     datas['ClientName']=data['details'][0]['client_name']
                  else:
                     datas['ClientName']=""
                  if data['details'][0]['host_attorney']:
                     datas['ProjectContact']=data['details'][0]['host_attorney']
                  else:
                     datas['ProjectContact']=""
                  if data['details'][0]['destination_city']:
                     datas['HostCity']=data['details'][0]['destination_city']
                  else:
                     datas['Host City']=""
                  if data['details'][0]['host_hr_name']:
                     datas['Host Contact Name']=data['details'][0]['host_hr_name']
                  else:
                     datas['HostContactName']=""

                  if data['details'][0]['host_country_head']:
                     datas['HostEntityName']=data['details'][0]['host_country_head']
                  else:
                     datas['HostEntityName']=""

                  if data['details'][0]['host_phone_no']:
                     phone=data['details'][0]['host_phone_no']
                  else:
                     phone=""
                  if data['details'][0]['host_phone_ext']:
                     ext=data['details'][0]['host_phone_ext']
                  else:
                     ext=""
                  datas['HostContactPhoneNumber']=ext+phone
                  if data['details'][0]['visa_number']:
                     datas['VisaNumber']=data['details'][0]['visa_number']
                  else:
                     datas['VisaNumber']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaValidity']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaValidity']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaCategory']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaCategory']=""
                  if data['details'][0]['agenda']:
                     datas['DayWiseAgenda']=data['details'][0]['agenda']
                  else:
                     datas['DayWiseAgenda']=""
                  if data['details'][0]['applicable_visa']:
                     datas['VisaType']=data['details'][0]['applicable_visa']
                  else:
                     datas['VisaType']=""
               datas['VisaCountry']=data['Host_Country']
               datas['HostCountry']=data['Host_Country'] 
               datas['HomeCountry']= data['Home_Country']
               if data['emp_passport']:
                  if data['emp_passport'][0]['passort_number']:
                     datas['PassportNumber']=data['emp_passport'][0]['passort_number']
                  else:
                     datas['PassportNumber']=""
                  if data['emp_passport'][0]['passort_expiry_date']:
                     datas['PassportValidity']=data['emp_passport'][0]['passort_expiry_date']
                  else:
                     datas['PassportValidity']=""
               if data['travel']:
                  if data['travel'][0]['project_name']:
                     datas['ProjectName']=data['travel'][0]['project_name']
                  else:
                     datas['ProjectName']=""   
                  if data['travel'][0]['project']:
                     datas['ProjectIDWBSECode']=data['travel'][0]['project']
                  else:
                     datas['ProjectIDWBSECode']=""
                  if data['travel'][0]['home_contact_name']:
                     datas['HomeEntityName']=data['travel'][0]['home_contact_name']
                  else:
                     datas['HomeEntityName']=""
            lettername=Letters.objects.filter(letter_type="Assignment Letter").values("letter_name")
            print(lettername)
            lettername=lettername[0]['letter_name'].lstrip('templates/')

            
            template = get_template(lettername)

            filenames = lettername.rstrip('.html')
            filename = filenames+'.pdf'

            html = template.render(datas)


            result = BytesIO()

            file = open("uploadpdf/"+filename, "w+b")
            #current_url = request.path_info
            #print(current_url)
            emp_codess="vikasy@triazinesoft.com"
            pisaStatus = pisa.CreatePDF(html.encode('utf-8'), dest=file, encoding='utf-8')
            email = EmailMessage(subject='Assignment Letter',
                                 body='Please Find the attachment report Below',
                                 from_email='vikasy@triazinesoft.com',
                                 to=[emp_code,'vikasy@triazinesoft.com'],
                                 headers = {'Reply-To': 'vikasy@triazinesoft.com'})

            # Open PDF file
            attachment = open('uploadpdf/'+filename, 'rb')

            # Attach PDF file
            email.attach(filename,attachment.read(),'application/pdf')

            # Send message with built-in send() method
            email.send()
            dict = {'massage': 'data found', 'status': True, 'data': 'uploadpdf/'+filename,'datakeys':datas }
        else:
            dict = {'massage': 'Assignment Not Generated', 'status': False}
        #dict = {'massage': 'data found', 'status': True, 'data': travel_request_serializer.data[0] }
        return Response(dict, status=status.HTTP_200_OK)

class getinviteletter(APIView):
    def get(self,request, *args, **kwargs):
        id=request.GET['travel_req_id']
        travel_request= Create_Assignment.objects.filter(Ticket_ID =request.GET['travel_req_id'])
        print(travel_request)
        if travel_request.exists():
            travel_request_serializer = Create_AssignmentSerializers(travel_request,many=True)
            emp_code=travel_request_serializer.data[0]['Employee_ID']
            emp = Employee.objects.filter(email=emp_code)
            emp_serializer = EmployeeSerializers(emp,many=True)
            travel_request_serializer.data[0]['emp_info']=emp_serializer.data
            empcode=emp_serializer.data[0]['emp_code']
            empadd = Employee_Address.objects.filter(emp_code=empcode,address_type="host")
            empadd_serializer = Employee_AddressSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_add']=empadd_serializer.data
            print(empadd_serializer.data)
            #travel_request_serializer.data[0]['date']=datetime.now().date().strftime("%d-%b-%Y")
            travel_requests=Travel_Request.objects.filter(travel_req_id =id)
            travel_request_serializers= Travel_RequestSerializers(travel_requests,many=True)
            travel_request_serializer.data[0]['travel']=travel_request_serializers.data
            travel_requestss=Travel_Request_Details.objects.filter(travel_req_id =id)
            travel_request_serializerss = Travel_Request_DetailsSerializers(travel_requestss,many=True)
            travel_request_serializer.data[0]['details']=travel_request_serializerss.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_passport']=emppassport_serializer.data
            '''empadd = Employee_Emails.objects.filter(emp_code=emp_code)
            empemails_serializer = Employee_EmailsSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emails']=empemails_serializer.data
            empadd = Employee_Emergency_Contact.objects.filter(emp_code=emp_code)
            empemergency_serializer = Employee_Emergency_ContactSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emergency']=empemergency_serializer.data
            empadd = Employee_Phones.objects.filter(emp_code=emp_code)
            empphones_serializer = Employee_PhonesSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_phones']=empphones_serializer.data
            empadd = Employee_Nationalid.objects.filter(emp_code=emp_code)
            empnational_serializer = Employee_NationalidSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_national']=empnational_serializer.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_passport']=emppassport_serializer.data
            empadd = Employee_Visa_Detail.objects.filter(emp_code=emp_code)
            empvisa_serializer = Employee_Visa_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_visa']=empvisa_serializer.data'''

            #data= travel_request_serializer.data
            #print(data)

            datas={}
            for data in travel_request_serializer.data:
               if data['emp_info']:
                  if data['emp_info'][0]['first_name']:
                     first_name=data['emp_info'][0]['first_name']
                  else:
                     first_name=""
                  if data['emp_info'][0]['last_name']:
                     last_name=data['emp_info'][0]['last_name']
                  else:
                     last_name=""
                  if data['emp_info'][0]['nationality']:
                     datas['Citizenship']=data['emp_info'][0]['nationality']
                  else:
                     datas['Citizenship']=""
                  
               datas['AssigneeName']=first_name+' '+last_name
               print(datas['AssigneeName'])
               datas['JobTitle']=""
               datas['TodayDate']=date.today()
               datas['AssignmentStartDate']=data['Actual_Start_Date']
               datas['AssignmentEndDate']=data['Actual_End_Date']
               datas['AssignmentType']=data['Assignment_Type']
               datas['TravelID']=data['Ticket_ID']
               datas['EmployeeID']=data['Employee_ID']
               print(data['details'])
               if data['details']:
                  if data['details'][0]['client_name']:
                     datas['ClientName']=data['details'][0]['client_name']
                  else:
                     datas['ClientName']=""
                  if data['details'][0]['host_attorney']:
                     datas['ProjectContact']=data['details'][0]['host_attorney']
                  else:
                     datas['ProjectContact']=""
                  if data['details'][0]['destination_city']:
                     datas['HostCity']=data['details'][0]['destination_city']
                  else:
                     datas['Host City']=""
                  if data['details'][0]['host_hr_name']:
                     datas['Host Contact Name']=data['details'][0]['host_hr_name']
                  else:
                     datas['HostContactName']=""

                  if data['details'][0]['host_country_head']:
                     datas['HostEntityName']=data['details'][0]['host_country_head']
                  else:
                     datas['HostEntityName']=""

                  if data['details'][0]['host_phone_no']:
                     phone=data['details'][0]['host_phone_no']
                  else:
                     phone=""
                  if data['details'][0]['host_phone_ext']:
                     ext=data['details'][0]['host_phone_ext']
                  else:
                     ext=""
                  datas['HostContactPhoneNumber']=ext+phone
                  if data['details'][0]['visa_number']:
                     datas['VisaNumber']=data['details'][0]['visa_number']
                  else:
                     datas['VisaNumber']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaValidity']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaValidity']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaCategory']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaCategory']=""
                  if data['details'][0]['agenda']:
                     datas['DayWiseAgenda']=data['details'][0]['agenda']
                  else:
                     datas['DayWiseAgenda']=""
                  if data['details'][0]['applicable_visa']:
                     datas['VisaType']=data['details'][0]['applicable_visa']
                  else:
                     datas['VisaType']=""
               datas['VisaCountry']=data['Host_Country']
               datas['HostCountry']=data['Host_Country'] 
               datas['HomeCountry']= data['Home_Country']
               if data['emp_passport']:
                  if data['emp_passport'][0]['passort_number']:
                     datas['PassportNumber']=data['emp_passport'][0]['passort_number']
                  else:
                     datas['PassportNumber']=""
                  if data['emp_passport'][0]['passort_expiry_date']:
                     datas['PassportValidity']=data['emp_passport'][0]['passort_expiry_date']
                  else:
                     datas['PassportValidity']=""
               if data['travel']:
                  if data['travel'][0]['project_name']:
                     datas['ProjectName']=data['travel'][0]['project_name']
                  else:
                     datas['ProjectName']=""   
                  if data['travel'][0]['project']:
                     datas['ProjectIDWBSECode']=data['travel'][0]['project']
                  else:
                     datas['ProjectIDWBSECode']=""
                  if data['travel'][0]['home_contact_name']:
                     datas['HomeEntityName']=data['travel'][0]['home_contact_name']
                  else:
                     datas['HomeEntityName']=""
            lettername=Letters.objects.filter(letter_type="Invite Letter").values("letter_name")
            lettername=lettername[0]['letter_name'].lstrip('templates/')

            #print(lettername)
            template = get_template(lettername)
            filenames = lettername.rstrip('.html')
            filename = filenames+'.pdf'
            #print(template)
            html = template.render(datas)
            result = BytesIO()
            file = open("uploadpdf/"+filename, "w+b")
            #current_url = request.path_info
            #print(current_url)
            emp_codess="vikasy@triazinesoft.com"
            pisaStatus = pisa.CreatePDF(html.encode('utf-8'), dest=file, encoding='utf-8')
            email = EmailMessage(subject='Invite Letter',
                                 body='Please Find the attachment report Below',
                                 from_email='vikasy@triazinesoft.com',
                                 to=[emp_code,'vikasy@triazinesoft.com'],
                                 headers = {'Reply-To': 'vikasy@triazinesoft.com'})

            # Open PDF file
            attachment = open('uploadpdf/'+filename, 'rb')

            # Attach PDF file
            email.attach(filename,attachment.read(),'application/pdf')

            # Send message with built-in send() method
            email.send()
            dict = {'massage': 'data found', 'status': True, 'data': 'uploadpdf/'+filename }
        else:
            dict = {'massage': 'data not found', 'status': False}
        #dict = {'massage': 'data found', 'status': True, 'data': travel_request_serializer.data[0] }
        return Response(dict, status=status.HTTP_200_OK)

class getvisaletter(APIView):
    def get(self,request, *args, **kwargs):
        id=request.GET['travel_req_id']
        travel_request= Create_Assignment.objects.filter(Ticket_ID =request.GET['travel_req_id'])
        print(travel_request)
        if travel_request.exists():
            travel_request_serializer = Create_AssignmentSerializers(travel_request,many=True)
            emp_code=travel_request_serializer.data[0]['Employee_ID']
            emp = Employee.objects.filter(email=emp_code)
            emp_serializer = EmployeeSerializers(emp,many=True)
            travel_request_serializer.data[0]['emp_info']=emp_serializer.data
            empcode=emp_serializer.data[0]['emp_code']
            empadd = Employee_Address.objects.filter(emp_code=empcode,address_type="host")
            empadd_serializer = Employee_AddressSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_add']=empadd_serializer.data
            print(empadd_serializer.data)
            #travel_request_serializer.data[0]['date']=datetime.now().date().strftime("%d-%b-%Y")
            travel_requests=Travel_Request.objects.filter(travel_req_id =id)
            travel_request_serializers= Travel_RequestSerializers(travel_requests,many=True)
            travel_request_serializer.data[0]['travel']=travel_request_serializers.data
            travel_requestss=Travel_Request_Details.objects.filter(travel_req_id =id)
            travel_request_serializerss = Travel_Request_DetailsSerializers(travel_requestss,many=True)
            travel_request_serializer.data[0]['details']=travel_request_serializerss.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            travel_request_serializer.data[0]['emp_passport']=emppassport_serializer.data
            '''empadd = Employee_Emails.objects.filter(emp_code=emp_code)
            empemails_serializer = Employee_EmailsSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emails']=empemails_serializer.data
            empadd = Employee_Emergency_Contact.objects.filter(emp_code=emp_code)
            empemergency_serializer = Employee_Emergency_ContactSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_emergency']=empemergency_serializer.data
            empadd = Employee_Phones.objects.filter(emp_code=emp_code)
            empphones_serializer = Employee_PhonesSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_phones']=empphones_serializer.data
            empadd = Employee_Nationalid.objects.filter(emp_code=emp_code)
            empnational_serializer = Employee_NationalidSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_national']=empnational_serializer.data
            empadd = Employee_Passport_Detail.objects.filter(emp_code=emp_code)
            emppassport_serializer = Employee_Passport_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_passport']=emppassport_serializer.data
            empadd = Employee_Visa_Detail.objects.filter(emp_code=emp_code)
            empvisa_serializer = Employee_Visa_DetailSerializers(empadd,many=True)
            emp_serializer.data[0]['emp_visa']=empvisa_serializer.data'''

            #data= travel_request_serializer.data
            #print(data)

            datas={}
            for data in travel_request_serializer.data:
               if data['emp_info']:
                  if data['emp_info'][0]['first_name']:
                     first_name=data['emp_info'][0]['first_name']
                  else:
                     first_name=""
                  if data['emp_info'][0]['last_name']:
                     last_name=data['emp_info'][0]['last_name']
                  else:
                     last_name=""
                  if data['emp_info'][0]['nationality']:
                     datas['Citizenship']=data['emp_info'][0]['nationality']
                  else:
                     datas['Citizenship']=""
                  
               datas['AssigneeName']=first_name+' '+last_name
               print(datas['AssigneeName'])
               datas['JobTitle']=""
               datas['TodayDate']=date.today()
               datas['AssignmentStartDate']=data['Actual_Start_Date']
               datas['AssignmentEndDate']=data['Actual_End_Date']
               datas['AssignmentType']=data['Assignment_Type']
               datas['TravelID']=data['Ticket_ID']
               datas['EmployeeID']=data['Employee_ID']
               print(data['details'])
               if data['details']:
                  if data['details'][0]['client_name']:
                     datas['ClientName']=data['details'][0]['client_name']
                  else:
                     datas['ClientName']=""
                  if data['details'][0]['host_attorney']:
                     datas['ProjectContact']=data['details'][0]['host_attorney']
                  else:
                     datas['ProjectContact']=""
                  if data['details'][0]['destination_city']:
                     datas['HostCity']=data['details'][0]['destination_city']
                  else:
                     datas['Host City']=""
                  if data['details'][0]['host_hr_name']:
                     datas['Host Contact Name']=data['details'][0]['host_hr_name']
                  else:
                     datas['HostContactName']=""

                  if data['details'][0]['host_country_head']:
                     datas['HostEntityName']=data['details'][0]['host_country_head']
                  else:
                     datas['HostEntityName']=""

                  if data['details'][0]['host_phone_no']:
                     phone=data['details'][0]['host_phone_no']
                  else:
                     phone=""
                  if data['details'][0]['host_phone_ext']:
                     ext=data['details'][0]['host_phone_ext']
                  else:
                     ext=""
                  datas['HostContactPhoneNumber']=ext+phone
                  if data['details'][0]['visa_number']:
                     datas['VisaNumber']=data['details'][0]['visa_number']
                  else:
                     datas['VisaNumber']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaValidity']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaValidity']=""
                  if data['details'][0]['visa_expiry_date']:
                     datas['VisaCategory']=data['details'][0]['visa_expiry_date']
                  else:
                     datas['VisaCategory']=""
                  if data['details'][0]['agenda']:
                     datas['DayWiseAgenda']=data['details'][0]['agenda']
                  else:
                     datas['DayWiseAgenda']=""
                  if data['details'][0]['applicable_visa']:
                     datas['VisaType']=data['details'][0]['applicable_visa']
                  else:
                     datas['VisaType']=""
               datas['VisaCountry']=data['Host_Country']
               datas['HostCountry']=data['Host_Country'] 
               datas['HomeCountry']= data['Home_Country']
               if data['emp_passport']:
                  if data['emp_passport'][0]['passort_number']:
                     datas['PassportNumber']=data['emp_passport'][0]['passort_number']
                  else:
                     datas['PassportNumber']=""
                  if data['emp_passport'][0]['passort_expiry_date']:
                     datas['PassportValidity']=data['emp_passport'][0]['passort_expiry_date']
                  else:
                     datas['PassportValidity']=""
               if data['travel']:
                  if data['travel'][0]['project_name']:
                     datas['ProjectName']=data['travel'][0]['project_name']
                  else:
                     datas['ProjectName']=""   
                  if data['travel'][0]['project']:
                     datas['ProjectIDWBSECode']=data['travel'][0]['project']
                  else:
                     datas['ProjectIDWBSECode']=""
                  if data['travel'][0]['home_contact_name']:
                     datas['HomeEntityName']=data['travel'][0]['home_contact_name']
                  else:
                     datas['HomeEntityName']=""
            lettername=Letters.objects.filter(letter_type="Visa Letter").values("letter_name")
            lettername=lettername[0]['letter_name'].lstrip('templates/')
            template = get_template(lettername)
            filenames = lettername.rstrip('.html')
            filename = filenames+'.pdf'
            #print(template)
            html = template.render(datas)
            result = BytesIO()
            file = open("uploadpdf/"+filename, "w+b")
            #current_url = request.path_info
            #print(current_url)
            emp_codess="vikasy@triazinesoft.com"
            pisaStatus = pisa.CreatePDF(html.encode('utf-8'), dest=file, encoding='utf-8')
            email = EmailMessage(subject='Visa Letter',
                                 body='Please Find the attachment report Below',
                                 from_email='vikasy@triazinesoft.com',
                                 to=[emp_code,'vikasy@triazinesoft.com'],
                                 headers = {'Reply-To': 'vikasy@triazinesoft.com'})

            # Open PDF file
            attachment = open('uploadpdf/'+filename, 'rb')

            # Attach PDF file
            email.attach(filename,attachment.read(),'application/pdf')

            # Send message with built-in send() method
            email.send()
            dict = {'massage': 'data found', 'status': True, 'data': 'uploadpdf/'+filename }
        else:
            dict = {'massage': 'data not found', 'status': False}
        #dict = {'massage': 'data found', 'status': True, 'data': travel_request_serializer.data[0] }
        return Response(dict, status=status.HTTP_200_OK)




class assignmentletterkeys(APIView):

    def get(self,request, *args, **kwargs):
        
        datas=['AssigneeName',
                'JobTitle',
                'TodayDate',
                'AssignmentStartDate'	,
                'AssignmentEndDate',	
                'AssignmentType',
                'TravelID',
                'EmployeeID',
                'ClientName',
                'ProjectName',
                'ProjectIDWBSECode',
                'ProjectContact',
                'HostCountry',	
                'HostCity',
                'HostEntityName',
                'HostContactName',
                'HostContactPhoneNumber',
                'HomeCountry',
                'HomeEntityName',
                'PassportNumber',	
                'PassportValidity',
                'Citizenship',
                'VisaCategory',
                'VisaNumber',
                'VisaCountry',	
                'VisaValidity'	,
                'DayWiseAgenda']
        datass=['Assignment Letter','Invite Letter','Visa Letter']
        dict = {'massage': 'data found', 'status': True,'Data':datas,'DataType':datass}
        return Response(dict, status=status.HTTP_200_OK)



class uploadletters(APIView):

    def get(self,request, *args, **kwargs):

        lettername=Letters.objects.all()
        serilaizer=LettersSerializers(lettername,many=True)
        dict = {'massage': 'data found', 'status': True,'Data':serilaizer.data}
        return Response(dict, status=status.HTTP_200_OK)
    def post(self,request, *args, **kwargs):

        lettername=Letters.objects.filter(letter_type=request.data['letter_type']).first()
        if lettername:
            lettername.delete()
            serilaizer=LettersSerializers(lettername,data=request.data)
            if serilaizer.is_valid():
                serilaizer.save()
                dict = {'massage': 'data found', 'status': True,'Data':serilaizer.data}
            else:
                dict = {'massage': 'data found', 'status': True,'Data':serilaizer.errors}
        else:
            serilaizer=LettersSerializers(data=request.data)
            if serilaizer.is_valid():
                serilaizer.save()
                dict = {'massage': 'data found', 'status': True,'Data':serilaizer.data}
            else:
                dict = {'massage': 'data found', 'status': True,'Data':serilaizer.errors}
        #dict = {'massage': 'data found', 'status': True, 'data': travel_request_serializer.data[0] }
        return Response(dict, status=status.HTTP_200_OK)

