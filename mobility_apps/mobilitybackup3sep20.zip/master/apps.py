from django.apps import AppConfig


class MasterDataConfig(AppConfig):
    name = 'master_data'
