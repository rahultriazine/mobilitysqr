# from rest_framework import serializers
# from . models import *
#
#
# class CountrySerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Country
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class OrganizationSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Organization
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
# class Visa_PurposeSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Visa_Purpose
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class VisaSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Visa
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class Visa_Document_ChecklistSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Visa_Document_Checklist
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
# class Assignment_TypeSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Assignment_Type
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class DepartmentSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Department
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class Organization_LocationSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Organization_Location
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
#
# class VendorSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Vendor
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
# class RoleSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Role
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
# class Request_StatusSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Request_Status
#         # fields = ('firstname','lastname')
#         fields = '__all__'
#
# class Activity_LogSerializers(serializers.ModelSerializer):
#     class Meta:
#         model =  Activity_Log
#         # fields = ('firstname','lastname')
#         fields = '__all__'