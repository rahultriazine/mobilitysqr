from rest_framework import serializers
from mobility_apps.master.models import Currency , Currency_Conversion

class CurrencySerializers(serializers.ModelSerializer):
    class Meta:
        model =  Currency
        # fields = ('firstname','lastname')
        fields = '__all__'

class Currency_ConversionSerializers(serializers.ModelSerializer):
    class Meta:
        model =  Currency_Conversion
        # fields = ('firstname','lastname')
        fields = '__all__'