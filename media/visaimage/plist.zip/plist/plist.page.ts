import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plist',
  templateUrl: './plist.page.html',
  styleUrls: ['./plist.page.scss'],
})
export class PlistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
